/**********************************************
 *  File Name        : updater.js
 *  Description      : FEVER NW 버전업데이트  
 *  Author            : KJS
 *  Date Created   : 2016-11-18
 * =============================================
 *  [변경 내역]
 *  [YY.MM.DD] [변경자] [변경내역]
 *  [16.11.18] KJS 최초등록
 **********************************************/

'use strict';

var UPDATER = (function (updater) {
  let win = require('nw.gui').Window.get();
  let fs = require("fs");
  let path = require("path");
  let request = require("request");
  let zip = require('node-zip-dir');
  let jsonfile = require('jsonfile');
  let configFilePath = './assets/config/';
  //로거
  let logger = require(configFilePath + 'logger');
  //FEVER 환경설정
  let config = require(configFilePath + 'env.json');
  let runMode = config.env;
  config = Object.assign({}, config, require(configFilePath + runMode +'.json'));

  //프로세스 실행 디렉토리 위치( ex) C:/FEVER-MANAGER/)
  let exepath = path.dirname(process.execPath);
  //원본 윈도우 넓이/높이
  let orgWH = {
    w: 0,
    h: 0
  };

  /**
   * 요청서버주소를 반환한다.
   * @method getRequestServerUrl
   * @param uri 요청주소
   * @return endpoint + uri를 반환한다.
   */
  function getRequestServerUrl(uri) {
    return config.endpoint + "/" + uri;
  };

  /**
   * 업데이트 진행 박스의 크기를 줄인다.
   * 
   * @method waitUpdate
   * @param updateBoxDom 업데이트UI DOM 오브젝트
   */
  function waitUpdate(updateBoxDom) {
    updateBoxDom.setAttribute("style", "display:block;");
    //원본 화면 크기 복원을 위해서 저장한다.
    orgWH.w = win.width;
    orgWH.h = win.height;

    win.resizeTo(280, 130);
    setTimeout(function () {
      win.setPosition("center");
      win.setProgressBar(1.1);
    }, 0);
  };

  /**
   * 현재 설치된 어플리케이션의 최신 버전을 확인 한다.
   * 
   * @public
   * @method check_for_update
   */
  updater.check_for_update = function check_for_update(appName, success, failure) {
    let local_version = config.version || "0.0.0";

    //최종버전 확인 거래 요청
    request({
      uri: getRequestServerUrl("check-update/" + appName),
      headers: {
        'Content-Type': 'text/json'
      }
    }, function (err, response, body) {
      if (!err && response.statusCode == 200) {
        let versionObj = JSON.parse(body);
        let latest = versionObj.version;
        let updateFileName = versionObj.fileName;

        //로컬 버전과 틀리면
        if (latest && latest.length && latest != local_version) {
          console.log("UPDATER : current version(%s), latest(%s)", local_version, latest);
          logger.info("UPDATER : current version(" + local_version + "), latest(" + latest + ")");
          success && success(latest, updateFileName);
        } else {
          //업데이트할 버전이 없다면 실패콜백에 0를 전달 한다.
          failure && failure(0, function (cb) {
            cb && cb();
          });
        }

      } else {
        console.log("UPDATER error: cannot access UpdateServer or appName(%s) not found, status(%s), err : %s, %s", appName, (response ? response.statusCode : "NaN"), err.code, err.message);
        logger.info("UPDATER error: cannot access UpdateServer or appName(" + appName + ") not found, status(" + (response ? response.statusCode : "NaN") + "), err : " + err.code + "," + err.message);
        //업데이트 체크 오류일때는 실패콜백에 1를 전달 한다.
        failure && failure(1, function (cb) {
          cb && cb();
        });
      }
    });
  };

  /**
   * 버전 업데이트 여부를 체크하여 최신버전으로 업데이트 한다.
   * 
   * @public
   * @method restart
   */
  updater.update = function (appName, callback, updateBoxDom) {
    //최초로그인이면 업데이트 체크는 무시 한다.
    if (config.isFirstLogin) {
      callback(0, function (cb) {
        cb && cb();
      })
      return false;
    }

    //업데이트 체크
    updater.check_for_update(appName, function update(latest_version, updateFileName) {
      //업데이트 할게 있다면 화면을 업데이트 대기상태로 만들어 준다. ============================
      waitUpdate(updateBoxDom);

      // output stream 생성 (기존에 dass-client-update.zip파일이 있으면  덮어쓴다.)
      let output = fs.createWriteStream(path.join(exepath, updateFileName))
        .on('close', function () {
          //TODO :: 덮어쓰기전 기존파일/디렉토리 삭제 할지 말지...

          //압축풀기
          zip.unzip(path.join(exepath, updateFileName), exepath).then(function () {
            console.debug('success unzip');
            logger.debug("success unzip");
            // 현재 업데이트 버전으로 환경설정 파일에 저정한다.
            config.version = latest_version;
            jsonfile.writeFile(configFilePath + 'env.json', config, {
              spaces: 2
            }, function () {});

            console.debug('updated to Version ::' + config.version);
            logger.debug('updated to Version ::' + config.version);

            //압축파일 삭제
            fs.unlink(path.join(exepath, updateFileName), function (err) {
              if (err) {
                console.error(err);
                logger.error(err);
              }
              updater.restart();
            });
          }).catch(function (err) {
            console.error(err);
            logger.error(err);
            //업데이트 파일 압축해제 실패시 실패콜백에 5을 전달 한다.
            callback && callback(5, function (cb) {
              win.resizeTo(orgWH.w, orgWH.h);
              setTimeout(function () {
                win.setPosition("center");
                win.setProgressBar(-1);
                cb && cb();
              }, 50);
            });
          });

        })
        .on('error', function (err) {
          console.error("stream error ::" + err);
          logger.error("stream error ::" + err);
          //업데이트 파일 오픈 실패시 실패콜백에 4을 전달 한다.
          callback && callback(4, function (cb) {
            win.resizeTo(orgWH.w, orgWH.h);
            setTimeout(function () {
              win.setPosition("center");
              win.setProgressBar(-1);
              cb && cb();
            }, 50);
          });
        });

      //최신 다운로드 거래 요청
      request(getRequestServerUrl("down-app/" + appName + "/" + latest_version + "/" + updateFileName + "/"))
        .on('response', function (response) {
          console.debug("download update file :: [" + response.statusCode + "], [" + response.statusMessage + "]");
          logger.debug("download update file :: [" + response.statusCode + "], [" + response.statusMessage + "]");
        }).on('error', function (err) {
          console.error("error download update file ::" + err);
          logger.error("error download update file :: " + err);
          //업데이트 파일다운로드 실패시 실패콜백에 3을 전달 한다.
          callback && callback(3, function (cb) {
            win.resizeTo(orgWH.w, orgWH.h);
            setTimeout(function () {
              win.setPosition("center");
              win.setProgressBar(-1);
              cb && cb();
            }, 50);
          });
        }).pipe(output);

    }, callback);
  };

  /**
   * 독립된 자식프로세스를 생성하여 업데이트 된 내용으로 부모를 재 실행 해 준다.
   * 
   * @public
   * @method restart
   */
  updater.restart = function () {
    let child_process = require("child_process");
    // 자식프로세스를 detached옵션을 현재 프로세스(부모) 부리된 자식 프로세스로 생성한다.(새로운 프로세스 그룹의 리더가 되어 부모가 종료된 후에도 자식 프로세스는 계속해서 동작 한다.)
    let child = child_process.spawn(process.execPath, [], {
      detached: true
    });

    //무보는 분리된 자식프로세스가 종료되길 기다리는데, 부모가 자식프로세스를 기다리지 않게 하려면 child.unref()를 호출하면 부모의 이벤트루프는 참조수에 자식을 포함시키지 않는다.
    child.unref();

    logger.info("update new version..., restart~~~!!!");

    // 현재 윈도우(프로세스)를 종료한다.
    win.close();
  };

  return updater;

}(UPDATER || {}));
